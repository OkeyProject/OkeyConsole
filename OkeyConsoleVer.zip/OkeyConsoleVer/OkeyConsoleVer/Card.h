#if !defined CARD_H
#define CARD_H

#include<iostream>
#include<string.h>
using namespace std;

class Card{
public:
	int number = 0;
	string color = "white";
};

#endif
